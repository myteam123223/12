const N_VIDEOS = 6

export { N_VIDEOS }
